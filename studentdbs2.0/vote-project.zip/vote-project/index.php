<?php
include("head.php");
?>
		<div class="sui-layout">
		  <div class="sidebar">
		  	<?php include("leftmenu.php");?>
		  </div>
		  <div class="content">
			<!-- <p class="sui-text-xxlarge my-padd label-success">欢迎访问候选人管理系统！</p> -->
		  </div>
		</div>		
	</div>
<?php 
include("foot.php");
?>