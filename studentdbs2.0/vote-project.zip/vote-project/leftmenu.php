<div class="box">
	<ul class="menu">
		<li class="level1">
			<a href="candidate-input.php">添加候选人</a>
			
		</li>
		<li class="level1">
			<a href="candidate-list.php">候选人列表</a>
			
		</li>
		
		
	</ul>
</div>